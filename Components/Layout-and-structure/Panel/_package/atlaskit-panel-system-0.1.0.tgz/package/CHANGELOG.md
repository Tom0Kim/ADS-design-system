# @atlaskit/panel-system

## 0.1.0

### Minor Changes

- [`660aaf04cc6f2`](https://bitbucket.org/atlassian/atlassian-frontend-monorepo/commits/660aaf04cc6f2) -
  Deprecating this package to move into private scope.

## 0.0.12

### Patch Changes

- Updated dependencies

## 0.0.11

### Patch Changes

- Updated dependencies

## 0.0.10

### Patch Changes

- Updated dependencies

## 0.0.9

### Patch Changes

- Updated dependencies

## 0.0.8

### Patch Changes

- Updated dependencies

## 0.0.7

### Patch Changes

- Updated dependencies

## 0.0.6

### Patch Changes

- [`a52ec0b1c0791`](https://bitbucket.org/atlassian/atlassian-frontend-monorepo/commits/a52ec0b1c0791) -
  Add PanelSubheader component, improve styles.

## 0.0.5

### Patch Changes

- Updated dependencies

## 0.0.4

### Patch Changes

- [`5bc5265a7d064`](https://bitbucket.org/atlassian/atlassian-frontend-monorepo/commits/5bc5265a7d064) -
  Create simple PanelFooter component.

## 0.0.3

### Patch Changes

- [`2500a40cc74bc`](https://bitbucket.org/atlassian/atlassian-frontend-monorepo/commits/2500a40cc74bc) -
  Create initial set of UI components.

## 0.0.2

### Patch Changes

- Updated dependencies
